package com.stackroute.oops.league.exception;

public class PlayerAlreadyExistsException extends RuntimeException {
    public PlayerAlreadyExistsException(String msg){
        super(msg);
    }
    
}
