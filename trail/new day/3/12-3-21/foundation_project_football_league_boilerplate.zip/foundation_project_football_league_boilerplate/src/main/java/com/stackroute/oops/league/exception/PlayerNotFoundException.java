package com.stackroute.oops.league.exception;

public class PlayerNotFoundException extends RuntimeException {
   public PlayerNotFoundException(String msg){
        super(msg);
    }
    
}
