export class Transaction{
    public description: string;
    // public category: string;
    public transactiondate: string;
    public amount: string;
  }
  